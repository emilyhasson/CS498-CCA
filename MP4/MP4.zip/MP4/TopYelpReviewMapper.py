#!/usr/bin/env python3
#TopYelpReviewMapper.py
import sys


top_businesses = []

for line in sys.stdin:
    print(line)
    # business_id, avg_score = line.split('\t')
    # print('%s\t%s' % (business_id, avg_score))